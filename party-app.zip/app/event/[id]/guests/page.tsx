"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter, useParams } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { BottomNav } from "@/components/bottom-nav"
import { SidebarNav } from "@/components/sidebar-nav"
import { ArrowLeft, UserPlus, Mail, Check, X } from "lucide-react"
import { mockEvents, mockUsers } from "@/lib/mock-data"
import type { Event } from "@/lib/types"

export default function GuestListPage() {
  const router = useRouter()
  const params = useParams()
  const [userRole, setUserRole] = useState<"host" | "guest" | null>(null)
  const [event, setEvent] = useState<Event | null>(null)
  const [newGuestEmail, setNewGuestEmail] = useState("")

  useEffect(() => {
    const role = localStorage.getItem("userRole") as "host" | "guest" | null
    if (!role) {
      router.push("/")
      return
    }
    setUserRole(role)

    const foundEvent = mockEvents.find((e) => e.id === params.id)
    setEvent(foundEvent || null)
  }, [router, params.id])

  const handleInviteGuest = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("[v0] Inviting guest:", newGuestEmail)
    setNewGuestEmail("")
  }

  if (!userRole || !event) {
    return null
  }

  const attendees = mockUsers.filter((u) => event.attendees.includes(u.id))
  const confirmedCount = attendees.length
  const pendingCount = 3

  return (
    <div className="min-h-screen bg-secondary">
      <div className="hidden lg:block">
        <SidebarNav userRole={userRole} />
      </div>

      <div className="lg:ml-64 pb-20 lg:pb-8">
        <header className="bg-background border-b sticky top-0 z-10">
          <div className="max-w-2xl mx-auto px-4 py-4 flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => router.back()}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-bold">Lista de Invitados</h1>
          </div>
        </header>

        <main className="max-w-2xl mx-auto px-4 py-6 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">{event.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 bg-secondary rounded-lg">
                  <p className="text-3xl font-bold text-primary">{confirmedCount}</p>
                  <p className="text-sm text-muted-foreground">Confirmados</p>
                </div>
                <div className="text-center p-4 bg-secondary rounded-lg">
                  <p className="text-3xl font-bold text-muted-foreground">{pendingCount}</p>
                  <p className="text-sm text-muted-foreground">Pendientes</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {userRole === "host" && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Invitar Nuevo Invitado</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleInviteGuest} className="flex gap-2">
                  <Input
                    type="email"
                    placeholder="correo@ejemplo.com"
                    value={newGuestEmail}
                    onChange={(e) => setNewGuestEmail(e.target.value)}
                    required
                  />
                  <Button type="submit" className="gap-2">
                    <UserPlus className="h-4 w-4" />
                    Invitar
                  </Button>
                </form>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Invitados Confirmados ({confirmedCount})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {attendees.map((attendee) => (
                  <div key={attendee.id} className="flex items-center gap-3 p-3 rounded-lg bg-secondary">
                    <Avatar>
                      <AvatarImage src={attendee.avatar || "/placeholder.svg"} alt={attendee.name} />
                      <AvatarFallback>{attendee.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="font-medium text-sm">{attendee.name}</p>
                      <p className="text-xs text-muted-foreground">{attendee.email}</p>
                    </div>
                    <Badge variant="default" className="gap-1">
                      <Check className="h-3 w-3" />
                      Confirmado
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Invitaciones Pendientes ({pendingCount})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { email: "maria@ejemplo.com", name: "María García" },
                  { email: "pedro@ejemplo.com", name: "Pedro Martínez" },
                  { email: "laura@ejemplo.com", name: "Laura Sánchez" },
                ].map((pending, index) => (
                  <div key={index} className="flex items-center gap-3 p-3 rounded-lg bg-secondary">
                    <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center">
                      <Mail className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-sm">{pending.name}</p>
                      <p className="text-xs text-muted-foreground">{pending.email}</p>
                    </div>
                    <Badge variant="secondary" className="gap-1">
                      <X className="h-3 w-3" />
                      Pendiente
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </main>
      </div>

      <div className="lg:hidden">
        <BottomNav userRole={userRole} />
      </div>
    </div>
  )
}
