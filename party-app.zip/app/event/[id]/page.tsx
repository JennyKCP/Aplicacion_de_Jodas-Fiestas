"use client"

import { useEffect, useState } from "react"
import { useRouter, useParams } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { BottomNav } from "@/components/bottom-nav"
import { SidebarNav } from "@/components/sidebar-nav"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Calendar,
  MapPin,
  Users,
  ArrowLeft,
  Edit,
  Trash2,
  MessageCircle,
  ShoppingCart,
  UserPlus,
  Map,
} from "lucide-react"
import { mockEvents, mockUsers } from "@/lib/mock-data"
import type { Event } from "@/lib/types"
import Image from "next/image"

export default function EventDetailPage() {
  const router = useRouter()
  const params = useParams()
  const [userRole, setUserRole] = useState<"host" | "guest" | null>(null)
  const [event, setEvent] = useState<Event | null>(null)

  useEffect(() => {
    const role = localStorage.getItem("userRole") as "host" | "guest" | null
    if (!role) {
      router.push("/")
      return
    }
    setUserRole(role)

    const foundEvent = mockEvents.find((e) => e.id === params.id)
    setEvent(foundEvent || null)
  }, [router, params.id])

  const handleEdit = () => {
    router.push(`/edit-event/${params.id}`)
  }

  const handleDelete = () => {
    if (confirm("¿Estás seguro de que quieres eliminar este evento?")) {
      console.log("[v0] Deleting event:", params.id)
      router.push("/feed")
    }
  }

  if (!userRole || !event) {
    return null
  }

  const host = mockUsers.find((u) => u.id === event.hostId)
  const attendees = event.attendees

  return (
    <div className="min-h-screen bg-secondary">
      <div className="hidden lg:block">
        <SidebarNav userRole={userRole} />
      </div>

      <div className="lg:ml-64 pb-20 lg:pb-8">
        <header className="bg-background border-b sticky top-0 z-10">
          <div className="max-w-2xl mx-auto px-4 py-4 flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => router.back()}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-bold flex-1">Detalles del Evento</h1>
            {userRole === "host" && (
              <div className="flex gap-2">
                <Button variant="ghost" size="icon" onClick={handleEdit}>
                  <Edit className="h-5 w-5" />
                </Button>
                <Button variant="ghost" size="icon" onClick={handleDelete}>
                  <Trash2 className="h-5 w-5" />
                </Button>
              </div>
            )}
          </div>
        </header>

        <main className="max-w-2xl mx-auto px-4 py-6 space-y-6">
          <div className="relative h-80 rounded-2xl overflow-hidden">
            <Image src={event.coverImage || "/placeholder.svg"} alt={event.name} fill className="object-cover" />
          </div>

          <Card>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="space-y-2 flex-1">
                  <CardTitle className="text-2xl">{event.name}</CardTitle>
                  <Badge variant="default">Próximo</Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">{event.description}</p>

              <Separator />

              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <Calendar className="h-5 w-5 text-primary" />
                  <div>
                    <p className="font-medium">Fecha y Hora</p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(event.date).toLocaleDateString("es-ES", {
                        weekday: "long",
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <MapPin className="h-5 w-5 text-primary" />
                  <div>
                    <p className="font-medium">Ubicación</p>
                    <p className="text-sm text-muted-foreground">{event.location}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <Users className="h-5 w-5 text-primary" />
                  <div>
                    <p className="font-medium">Asistentes</p>
                    <p className="text-sm text-muted-foreground">{event.attendees.length} confirmados</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {userRole === "host" && (
            <div className="grid grid-cols-2 gap-3">
              <Button
                variant="outline"
                className="gap-2 bg-transparent"
                onClick={() => router.push(`/event/${params.id}/guests`)}
              >
                <UserPlus className="h-4 w-4" />
                Lista de Invitados
              </Button>
              <Button
                variant="outline"
                className="gap-2 bg-transparent"
                onClick={() => router.push(`/event/${params.id}/shopping`)}
              >
                <ShoppingCart className="h-4 w-4" />
                Lista de Compras
              </Button>
            </div>
          )}

          <Button
            variant="outline"
            className="w-full gap-2 bg-transparent"
            onClick={() => router.push(`/event/${params.id}/map`)}
          >
            <Map className="h-4 w-4" />
            Ver Mapa del Evento
          </Button>

          <Tabs defaultValue="host" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="host">Anfitrión</TabsTrigger>
              <TabsTrigger value="attendees">Asistentes</TabsTrigger>
              <TabsTrigger value="comments">Comentarios</TabsTrigger>
            </TabsList>

            <TabsContent value="host" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Información del Anfitrión</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-3">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={host?.avatar || "/placeholder.svg"} alt={host?.name} />
                      <AvatarFallback>{host?.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold">{host?.name}</p>
                      <p className="text-sm text-muted-foreground">{host?.email}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="attendees" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Asistentes Confirmados ({attendees.length})</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {attendees.map((attendee) => (
                      <div key={attendee.id} className="flex items-center gap-3">
                        <Avatar>
                          <AvatarImage src={attendee.avatar || "/placeholder.svg"} alt={attendee.name} />
                          <AvatarFallback>{attendee.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <p className="font-medium text-sm">{attendee.name}</p>
                          <Badge variant="outline" className="text-xs mt-1">
                            {attendee.status === "confirmed"
                              ? "Confirmado"
                              : attendee.status === "pending"
                                ? "Pendiente"
                                : attendee.status === "maybe"
                                  ? "Tal vez"
                                  : "Declinado"}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="comments" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Comentarios y Recuerdos</CardTitle>
                </CardHeader>
                <CardContent>
                  {event.comments.length > 0 ? (
                    <div className="space-y-4">
                      {event.comments.map((comment) => (
                        <div key={comment.id} className="flex gap-3">
                          <Avatar>
                            <AvatarImage src={comment.userAvatar || "/placeholder.svg"} alt={comment.userName} />
                            <AvatarFallback>{comment.userName.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <p className="font-semibold text-sm">{comment.userName}</p>
                            <p className="text-sm text-muted-foreground">{comment.text}</p>
                            <p className="text-xs text-muted-foreground mt-1">
                              {new Date(comment.timestamp).toLocaleDateString("es-ES")}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-8 text-center">
                      <MessageCircle className="h-12 w-12 text-muted-foreground mb-3" />
                      <p className="text-muted-foreground">No hay comentarios todavía</p>
                      <p className="text-sm text-muted-foreground mt-1">Sé el primero en compartir un recuerdo</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {userRole === "guest" && (
            <Button className="w-full" size="lg">
              Confirmar Asistencia
            </Button>
          )}
        </main>
      </div>

      <div className="lg:hidden">
        <BottomNav userRole={userRole} />
      </div>
    </div>
  )
}
