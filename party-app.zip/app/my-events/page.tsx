"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BottomNav } from "@/components/bottom-nav"
import { SidebarNav } from "@/components/sidebar-nav"
import { Calendar, MapPin, Users, Plus } from "lucide-react"
import { mockEvents, mockUsers } from "@/lib/mock-data"
import type { Event } from "@/lib/types"
import Image from "next/image"

export default function MyEventsPage() {
  const router = useRouter()
  const [userRole, setUserRole] = useState<"host" | "guest" | null>(null)
  const [userId, setUserId] = useState<string | null>(null)
  const [myEvents, setMyEvents] = useState<Event[]>([])
  const [attendingEvents, setAttendingEvents] = useState<Event[]>([])

  useEffect(() => {
    // Check if user is logged in
    const role = localStorage.getItem("userRole") as "host" | "guest" | null
    const storedUserId = localStorage.getItem("userId") || "1"

    if (!role) {
      router.push("/")
      return
    }

    setUserRole(role)
    setUserId(storedUserId)

    // Filter events based on user role
    if (role === "host") {
      // Show events hosted by this user
      const hosted = mockEvents.filter((event) => event.hostId === storedUserId)
      setMyEvents(hosted)
    } else {
      // Show events where user is an attendee
      const attending = mockEvents.filter((event) => event.attendees.some((attendee) => attendee.id === storedUserId))
      setAttendingEvents(attending)
    }
  }, [router])

  const handleEventClick = (eventId: string) => {
    router.push(`/event/${eventId}`)
  }

  const handleCreateEvent = () => {
    router.push("/create-event")
  }

  if (!userRole) {
    return null
  }

  const upcomingEvents = (userRole === "host" ? myEvents : attendingEvents).filter(
    (event) => new Date(event.date) >= new Date(),
  )
  const pastEvents = (userRole === "host" ? myEvents : attendingEvents).filter(
    (event) => new Date(event.date) < new Date(),
  )

  return (
    <div className="min-h-screen bg-secondary">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block">
        <SidebarNav userRole={userRole} />
      </div>

      {/* Main Content */}
      <div className="lg:ml-64 pb-20 lg:pb-8">
        {/* Header */}
        <header className="bg-background border-b sticky top-0 z-10">
          <div className="max-w-2xl mx-auto px-4 py-4 flex items-center justify-between">
            <h1 className="text-2xl font-bold">{userRole === "host" ? "Mis Eventos" : "Mis Invitaciones"}</h1>
            {userRole === "host" && (
              <Button onClick={handleCreateEvent} size="sm" className="gap-2">
                <Plus className="h-4 w-4" />
                Crear Evento
              </Button>
            )}
          </div>
        </header>

        {/* Events Tabs */}
        <main className="max-w-2xl mx-auto px-4 py-6">
          <Tabs defaultValue="upcoming" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="upcoming">Próximos</TabsTrigger>
              <TabsTrigger value="past">Pasados</TabsTrigger>
            </TabsList>

            <TabsContent value="upcoming" className="space-y-4">
              {upcomingEvents.length === 0 ? (
                <Card className="p-8 text-center">
                  <p className="text-muted-foreground mb-4">
                    {userRole === "host" ? "No tienes eventos próximos" : "No tienes invitaciones próximas"}
                  </p>
                  {userRole === "host" && (
                    <Button onClick={handleCreateEvent} className="gap-2">
                      <Plus className="h-4 w-4" />
                      Crear tu primer evento
                    </Button>
                  )}
                </Card>
              ) : (
                upcomingEvents.map((event) => {
                  const host = mockUsers.find((u) => u.id === event.hostId)
                  const userAttendee = event.attendees.find((a) => a.id === userId)

                  return (
                    <Card
                      key={event.id}
                      className="overflow-hidden cursor-pointer hover:shadow-lg transition-shadow"
                      onClick={() => handleEventClick(event.id)}
                    >
                      <div className="flex gap-4">
                        {/* Event Image */}
                        <div className="relative w-32 h-32 flex-shrink-0 bg-muted">
                          <Image
                            src={event.coverImage || "/placeholder.svg"}
                            alt={event.name}
                            fill
                            className="object-cover"
                          />
                        </div>

                        {/* Event Info */}
                        <div className="flex-1 py-3 pr-4">
                          <div className="flex items-start justify-between mb-2">
                            <h3 className="font-bold text-lg line-clamp-1">{event.name}</h3>
                            {userRole === "guest" && userAttendee && (
                              <Badge
                                variant={
                                  userAttendee.status === "confirmed"
                                    ? "default"
                                    : userAttendee.status === "maybe"
                                      ? "secondary"
                                      : "outline"
                                }
                              >
                                {userAttendee.status === "confirmed"
                                  ? "Confirmado"
                                  : userAttendee.status === "maybe"
                                    ? "Tal vez"
                                    : "Pendiente"}
                              </Badge>
                            )}
                          </div>

                          <div className="space-y-1 text-sm text-muted-foreground">
                            <div className="flex items-center gap-2">
                              <Calendar className="h-4 w-4" />
                              <span>
                                {new Date(event.date).toLocaleDateString("es-ES", {
                                  month: "short",
                                  day: "numeric",
                                  year: "numeric",
                                })}
                              </span>
                            </div>
                            <div className="flex items-center gap-2">
                              <MapPin className="h-4 w-4" />
                              <span className="line-clamp-1">{event.location}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Users className="h-4 w-4" />
                              <span>{event.attendees.length} asistentes</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Card>
                  )
                })
              )}
            </TabsContent>

            <TabsContent value="past" className="space-y-4">
              {pastEvents.length === 0 ? (
                <Card className="p-8 text-center">
                  <p className="text-muted-foreground">
                    {userRole === "host" ? "No tienes eventos pasados" : "No tienes invitaciones pasadas"}
                  </p>
                </Card>
              ) : (
                pastEvents.map((event) => {
                  const host = mockUsers.find((u) => u.id === event.hostId)

                  return (
                    <Card
                      key={event.id}
                      className="overflow-hidden cursor-pointer hover:shadow-lg transition-shadow opacity-75"
                      onClick={() => handleEventClick(event.id)}
                    >
                      <div className="flex gap-4">
                        {/* Event Image */}
                        <div className="relative w-32 h-32 flex-shrink-0 bg-muted">
                          <Image
                            src={event.coverImage || "/placeholder.svg"}
                            alt={event.name}
                            fill
                            className="object-cover grayscale"
                          />
                        </div>

                        {/* Event Info */}
                        <div className="flex-1 py-3 pr-4">
                          <div className="flex items-start justify-between mb-2">
                            <h3 className="font-bold text-lg line-clamp-1">{event.name}</h3>
                            <Badge variant="secondary">Finalizado</Badge>
                          </div>

                          <div className="space-y-1 text-sm text-muted-foreground">
                            <div className="flex items-center gap-2">
                              <Calendar className="h-4 w-4" />
                              <span>
                                {new Date(event.date).toLocaleDateString("es-ES", {
                                  month: "short",
                                  day: "numeric",
                                  year: "numeric",
                                })}
                              </span>
                            </div>
                            <div className="flex items-center gap-2">
                              <MapPin className="h-4 w-4" />
                              <span className="line-clamp-1">{event.location}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Users className="h-4 w-4" />
                              <span>{event.attendees.length} asistentes</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Card>
                  )
                })
              )}
            </TabsContent>
          </Tabs>
        </main>
      </div>

      {/* Mobile Bottom Navigation */}
      <div className="lg:hidden">
        <BottomNav userRole={userRole} />
      </div>
    </div>
  )
}
