export type UserRole = "host" | "guest"

export interface User {
  id: string
  name: string
  email: string
  role: UserRole
  avatar?: string
}

export interface Event {
  id: string
  name: string
  date: string
  time: string
  location: string
  description: string
  coverImage: string
  category: "birthday" | "wedding" | "concert" | "corporate" | "other"
  hostId: string
  hostName: string
  attendees: Attendee[]
  shoppingList: ShoppingItem[]
  comments: Comment[]
  photos: string[]
}

export interface Attendee {
  id: string
  name: string
  avatar?: string
  status: "confirmed" | "pending" | "declined" | "maybe"
}

export interface ShoppingItem {
  id: string
  name: string
  quantity: number
  price: number
  purchased: boolean
}

export interface Comment {
  id: string
  userId: string
  userName: string
  userAvatar?: string
  text: string
  timestamp: string
  photo?: string
}

export interface Reminder {
  id: string
  eventId: string
  daysBeforeEvent: number
  active: boolean
}
