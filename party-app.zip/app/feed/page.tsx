"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { BottomNav } from "@/components/bottom-nav"
import { SidebarNav } from "@/components/sidebar-nav"
import { Calendar, MapPin, Users, Heart, MessageCircle, Share2, Plus } from "lucide-react"
import { mockEvents, mockUsers } from "@/lib/mock-data"
import type { Event } from "@/lib/types"
import Image from "next/image"

export default function FeedPage() {
  const router = useRouter()
  const [userRole, setUserRole] = useState<"host" | "guest" | null>(null)
  const [events, setEvents] = useState<Event[]>([])
  const [likedEvents, setLikedEvents] = useState<Set<string>>(new Set())

  useEffect(() => {
    // Check if user is logged in
    const role = localStorage.getItem("userRole") as "host" | "guest" | null
    if (!role) {
      router.push("/")
      return
    }
    setUserRole(role)

    // Load mock events
    setEvents(mockEvents)
  }, [router])

  const handleLike = (eventId: string) => {
    setLikedEvents((prev) => {
      const newSet = new Set(prev)
      if (newSet.has(eventId)) {
        newSet.delete(eventId)
      } else {
        newSet.add(eventId)
      }
      return newSet
    })
  }

  const handleEventClick = (eventId: string) => {
    router.push(`/event/${eventId}`)
  }

  const handleCreateEvent = () => {
    router.push("/create-event")
  }

  if (!userRole) {
    return null
  }

  return (
    <div className="min-h-screen bg-secondary">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block">
        <SidebarNav userRole={userRole} />
      </div>

      {/* Main Content */}
      <div className="lg:ml-64 pb-20 lg:pb-8">
        {/* Header */}
        <header className="bg-background border-b sticky top-0 z-10">
          <div className="max-w-2xl mx-auto px-4 py-4 flex items-center justify-between">
            <h1 className="text-2xl font-bold text-primary">PartyHub</h1>
            {userRole === "host" && (
              <Button onClick={handleCreateEvent} size="sm" className="gap-2">
                <Plus className="h-4 w-4" />
                Crear Evento
              </Button>
            )}
          </div>
        </header>

        {/* Feed */}
        <main className="max-w-2xl mx-auto px-4 py-6 space-y-6">
          {events.map((event) => {
            const host = mockUsers.find((u) => u.id === event.hostId)
            const isLiked = likedEvents.has(event.id)

            return (
              <Card key={event.id} className="overflow-hidden shadow-md hover:shadow-lg transition-shadow">
                {/* Event Header */}
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage src={host?.avatar || "/placeholder.svg"} alt={host?.name} />
                      <AvatarFallback>{host?.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="font-semibold text-sm">{host?.name}</p>
                      <p className="text-xs text-muted-foreground">Anfitrión</p>
                    </div>
                    <Badge variant="default">Próximo</Badge>
                  </div>
                </CardHeader>

                {/* Event Image */}
                <div className="relative h-64 bg-muted cursor-pointer" onClick={() => handleEventClick(event.id)}>
                  <Image src={event.coverImage || "/placeholder.svg"} alt={event.name} fill className="object-cover" />
                </div>

                {/* Event Content */}
                <CardContent className="pt-4 space-y-3">
                  <div>
                    <h3
                      className="font-bold text-lg mb-1 cursor-pointer hover:text-primary transition-colors"
                      onClick={() => handleEventClick(event.id)}
                    >
                      {event.name}
                    </h3>
                    <p className="text-sm text-muted-foreground line-clamp-2">{event.description}</p>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Calendar className="h-4 w-4" />
                      <span>
                        {new Date(event.date).toLocaleDateString("es-ES", {
                          weekday: "long",
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        })}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      <span>{event.location}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Users className="h-4 w-4" />
                      <span>{event.attendees.length} asistentes confirmados</span>
                    </div>
                  </div>
                </CardContent>

                {/* Event Actions */}
                <CardFooter className="pt-0 pb-4 gap-4">
                  <Button variant="ghost" size="sm" className="gap-2" onClick={() => handleLike(event.id)}>
                    <Heart className={`h-5 w-5 ${isLiked ? "fill-primary text-primary" : ""}`} />
                    <span className="text-sm">{isLiked ? "Te gusta" : "Me gusta"}</span>
                  </Button>
                  <Button variant="ghost" size="sm" className="gap-2" onClick={() => handleEventClick(event.id)}>
                    <MessageCircle className="h-5 w-5" />
                    <span className="text-sm">Comentar</span>
                  </Button>
                  <Button variant="ghost" size="sm" className="gap-2">
                    <Share2 className="h-5 w-5" />
                    <span className="text-sm">Compartir</span>
                  </Button>
                </CardFooter>
              </Card>
            )
          })}
        </main>
      </div>

      {/* Mobile Bottom Navigation */}
      <div className="lg:hidden">
        <BottomNav userRole={userRole} />
      </div>
    </div>
  )
}
