"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BottomNav } from "@/components/bottom-nav"
import { SidebarNav } from "@/components/sidebar-nav"
import { ArrowLeft, Calendar, MapPin, Users } from "lucide-react"
import { mockEvents, mockUsers } from "@/lib/mock-data"
import Image from "next/image"

export default function HistoryPage() {
  const router = useRouter()
  const [userRole, setUserRole] = useState<"host" | "guest" | null>(null)

  useEffect(() => {
    const role = localStorage.getItem("userRole") as "host" | "guest" | null
    if (!role) {
      router.push("/")
      return
    }
    setUserRole(role)
  }, [router])

  if (!userRole) {
    return null
  }

  const currentUser = mockUsers[0]
  const upcomingEvents = mockEvents.filter((e) => e.status === "upcoming")
  const pastEvents = mockEvents.filter((e) => e.status === "past")

  const renderEventCard = (event: (typeof mockEvents)[0]) => {
    const host = mockUsers.find((u) => u.id === event.hostId)

    return (
      <Card
        key={event.id}
        className="overflow-hidden cursor-pointer hover:shadow-lg transition-shadow"
        onClick={() => router.push(`/event/${event.id}`)}
      >
        <div className="relative h-48 bg-muted">
          <Image src={event.image || "/placeholder.svg"} alt={event.title} fill className="object-cover" />
        </div>
        <CardHeader className="pb-3">
          <div className="flex items-center gap-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src={host?.avatar || "/placeholder.svg"} alt={host?.name} />
              <AvatarFallback>{host?.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h3 className="font-bold text-lg">{event.title}</h3>
              <p className="text-xs text-muted-foreground">{host?.name}</p>
            </div>
            <Badge variant={event.status === "upcoming" ? "default" : "secondary"}>
              {event.status === "upcoming" ? "Próximo" : "Pasado"}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Calendar className="h-4 w-4" />
            <span>
              {new Date(event.date).toLocaleDateString("es-ES", {
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <MapPin className="h-4 w-4" />
            <span>{event.location}</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Users className="h-4 w-4" />
            <span>{event.attendees.length} asistentes</span>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="min-h-screen bg-secondary">
      <div className="hidden lg:block">
        <SidebarNav userRole={userRole} />
      </div>

      <div className="lg:ml-64 pb-20 lg:pb-8">
        <header className="bg-background border-b sticky top-0 z-10">
          <div className="max-w-2xl mx-auto px-4 py-4 flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => router.back()}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-bold">Historial de Eventos</h1>
          </div>
        </header>

        <main className="max-w-2xl mx-auto px-4 py-6">
          <Tabs defaultValue="upcoming" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="upcoming">Próximos ({upcomingEvents.length})</TabsTrigger>
              <TabsTrigger value="past">Pasados ({pastEvents.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="upcoming" className="space-y-4">
              {upcomingEvents.length > 0 ? (
                upcomingEvents.map(renderEventCard)
              ) : (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                    <Calendar className="h-12 w-12 text-muted-foreground mb-3" />
                    <p className="text-muted-foreground">No tienes eventos próximos</p>
                    <p className="text-sm text-muted-foreground mt-1">Explora el feed para descubrir nuevos eventos</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="past" className="space-y-4">
              {pastEvents.length > 0 ? (
                pastEvents.map(renderEventCard)
              ) : (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                    <Calendar className="h-12 w-12 text-muted-foreground mb-3" />
                    <p className="text-muted-foreground">No tienes eventos pasados</p>
                    <p className="text-sm text-muted-foreground mt-1">Tus eventos anteriores aparecerán aquí</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </main>
      </div>

      <div className="lg:hidden">
        <BottomNav userRole={userRole} />
      </div>
    </div>
  )
}
