"use client"

import { Home, Search, PlusCircle, Calendar, User } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

interface SidebarNavProps {
  userRole: "host" | "guest"
}

export function SidebarNav({ userRole }: SidebarNavProps) {
  const pathname = usePathname()

  const navItems = [
    { href: "/feed", icon: Home, label: "Inicio" },
    { href: "/search", icon: Search, label: "Buscar" },
    ...(userRole === "host" ? [{ href: "/create-event", icon: PlusCircle, label: "Crear Evento" }] : []),
    { href: "/my-events", icon: Calendar, label: "Mis Eventos" },
    { href: "/profile", icon: User, label: "Perfil" },
  ]

  return (
    <aside className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0 bg-card border-r border-border">
      <div className="flex flex-col flex-1 overflow-y-auto pt-8 pb-4">
        <div className="flex items-center flex-shrink-0 px-6 mb-8">
          <h1 className="text-2xl font-bold text-primary">PartyHub</h1>
        </div>
        <nav className="flex-1 px-4 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon
            const isActive = pathname === item.href

            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-lg transition-colors font-medium",
                  isActive ? "bg-primary text-primary-foreground" : "text-foreground hover:bg-secondary",
                )}
              >
                <Icon className="h-5 w-5" />
                <span>{item.label}</span>
              </Link>
            )
          })}
        </nav>
      </div>
    </aside>
  )
}
