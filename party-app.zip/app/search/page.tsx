"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { BottomNav } from "@/components/bottom-nav"
import { SidebarNav } from "@/components/sidebar-nav"
import { Search, Calendar, MapPin, Users, Filter } from "lucide-react"
import { mockEvents, mockUsers } from "@/lib/mock-data"
import Image from "next/image"

export default function SearchPage() {
  const router = useRouter()
  const [userRole, setUserRole] = useState<"host" | "guest" | null>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [filteredEvents, setFilteredEvents] = useState(mockEvents)

  useEffect(() => {
    const role = localStorage.getItem("userRole") as "host" | "guest" | null
    if (!role) {
      router.push("/")
      return
    }
    setUserRole(role)
  }, [router])

  useEffect(() => {
    if (searchQuery.trim() === "") {
      setFilteredEvents(mockEvents)
    } else {
      const filtered = mockEvents.filter(
        (event) =>
          event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          event.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          event.location.toLowerCase().includes(searchQuery.toLowerCase()),
      )
      setFilteredEvents(filtered)
    }
  }, [searchQuery])

  if (!userRole) {
    return null
  }

  return (
    <div className="min-h-screen bg-secondary">
      <div className="hidden lg:block">
        <SidebarNav userRole={userRole} />
      </div>

      <div className="lg:ml-64 pb-20 lg:pb-8">
        <header className="bg-background border-b sticky top-0 z-10">
          <div className="max-w-2xl mx-auto px-4 py-4">
            <h1 className="text-xl font-bold mb-4">Buscar Eventos</h1>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por nombre, ubicación..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Button variant="outline" size="icon" className="bg-transparent">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </header>

        <main className="max-w-2xl mx-auto px-4 py-6 space-y-4">
          {filteredEvents.length > 0 ? (
            filteredEvents.map((event) => {
              const host = mockUsers.find((u) => u.id === event.hostId)

              return (
                <Card
                  key={event.id}
                  className="overflow-hidden cursor-pointer hover:shadow-lg transition-shadow"
                  onClick={() => router.push(`/event/${event.id}`)}
                >
                  <div className="relative h-48 bg-muted">
                    <Image src={event.image || "/placeholder.svg"} alt={event.title} fill className="object-cover" />
                  </div>
                  <CardHeader className="pb-3">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={host?.avatar || "/placeholder.svg"} alt={host?.name} />
                        <AvatarFallback>{host?.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <h3 className="font-bold text-lg">{event.title}</h3>
                        <p className="text-xs text-muted-foreground">{host?.name}</p>
                      </div>
                      <Badge variant={event.status === "upcoming" ? "default" : "secondary"}>
                        {event.status === "upcoming" ? "Próximo" : "Pasado"}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Calendar className="h-4 w-4" />
                      <span>
                        {new Date(event.date).toLocaleDateString("es-ES", {
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        })}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      <span>{event.location}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Users className="h-4 w-4" />
                      <span>{event.attendees.length} asistentes</span>
                    </div>
                  </CardContent>
                </Card>
              )
            })
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                <Search className="h-12 w-12 text-muted-foreground mb-3" />
                <p className="text-muted-foreground">No se encontraron eventos</p>
                <p className="text-sm text-muted-foreground mt-1">Intenta con otros términos de búsqueda</p>
              </CardContent>
            </Card>
          )}
        </main>
      </div>

      <div className="lg:hidden">
        <BottomNav userRole={userRole} />
      </div>
    </div>
  )
}
