"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter, useParams } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { BottomNav } from "@/components/bottom-nav"
import { SidebarNav } from "@/components/sidebar-nav"
import { ArrowLeft, Plus, Trash2, ShoppingCart } from "lucide-react"
import { mockEvents } from "@/lib/mock-data"
import type { Event } from "@/lib/types"

interface ShoppingItem {
  id: string
  name: string
  quantity: string
  category: string
  completed: boolean
  assignedTo?: string
}

export default function ShoppingListPage() {
  const router = useRouter()
  const params = useParams()
  const [userRole, setUserRole] = useState<"host" | "guest" | null>(null)
  const [event, setEvent] = useState<Event | null>(null)
  const [newItem, setNewItem] = useState({ name: "", quantity: "" })
  const [items, setItems] = useState<ShoppingItem[]>([
    { id: "1", name: "Bebidas", quantity: "20 unidades", category: "Bebidas", completed: false },
    { id: "2", name: "Platos desechables", quantity: "50 unidades", category: "Vajilla", completed: true },
    { id: "3", name: "Decoraciones", quantity: "1 set", category: "Decoración", completed: false },
    { id: "4", name: "Pastel", quantity: "1 unidad", category: "Comida", completed: false },
    { id: "5", name: "Servilletas", quantity: "100 unidades", category: "Vajilla", completed: true },
  ])

  useEffect(() => {
    const role = localStorage.getItem("userRole") as "host" | "guest" | null
    if (!role) {
      router.push("/")
      return
    }
    if (role !== "host") {
      router.push("/feed")
      return
    }
    setUserRole(role)

    const foundEvent = mockEvents.find((e) => e.id === params.id)
    setEvent(foundEvent || null)
  }, [router, params.id])

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault()
    if (newItem.name && newItem.quantity) {
      const item: ShoppingItem = {
        id: Date.now().toString(),
        name: newItem.name,
        quantity: newItem.quantity,
        category: "General",
        completed: false,
      }
      setItems([...items, item])
      setNewItem({ name: "", quantity: "" })
    }
  }

  const handleToggleItem = (id: string) => {
    setItems(items.map((item) => (item.id === id ? { ...item, completed: !item.completed } : item)))
  }

  const handleDeleteItem = (id: string) => {
    setItems(items.filter((item) => item.id !== id))
  }

  if (!userRole || !event) {
    return null
  }

  const completedCount = items.filter((item) => item.completed).length
  const totalCount = items.length
  const progress = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0

  return (
    <div className="min-h-screen bg-secondary">
      <div className="hidden lg:block">
        <SidebarNav userRole={userRole} />
      </div>

      <div className="lg:ml-64 pb-20 lg:pb-8">
        <header className="bg-background border-b sticky top-0 z-10">
          <div className="max-w-2xl mx-auto px-4 py-4 flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => router.back()}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-bold">Lista de Compras</h1>
          </div>
        </header>

        <main className="max-w-2xl mx-auto px-4 py-6 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">{event.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Progreso</span>
                  <span className="text-sm font-medium">
                    {completedCount} de {totalCount} completados
                  </span>
                </div>
                <div className="w-full bg-secondary rounded-full h-3">
                  <div
                    className="bg-primary h-3 rounded-full transition-all duration-300"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Agregar Artículo</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAddItem} className="space-y-3">
                <div className="flex gap-2">
                  <Input
                    placeholder="Nombre del artículo"
                    value={newItem.name}
                    onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
                    required
                  />
                  <Input
                    placeholder="Cantidad"
                    value={newItem.quantity}
                    onChange={(e) => setNewItem({ ...newItem, quantity: e.target.value })}
                    className="w-32"
                    required
                  />
                </div>
                <Button type="submit" className="w-full gap-2">
                  <Plus className="h-4 w-4" />
                  Agregar a la Lista
                </Button>
              </form>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Artículos ({totalCount})</CardTitle>
                <ShoppingCart className="h-5 w-5 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {items.map((item) => (
                  <div
                    key={item.id}
                    className={`flex items-center gap-3 p-3 rounded-lg bg-secondary ${
                      item.completed ? "opacity-60" : ""
                    }`}
                  >
                    <Checkbox checked={item.completed} onCheckedChange={() => handleToggleItem(item.id)} />
                    <div className="flex-1">
                      <p className={`font-medium text-sm ${item.completed ? "line-through" : ""}`}>{item.name}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <p className="text-xs text-muted-foreground">{item.quantity}</p>
                        <Badge variant="outline" className="text-xs">
                          {item.category}
                        </Badge>
                      </div>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => handleDeleteItem(item.id)}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </main>
      </div>

      <div className="lg:hidden">
        <BottomNav userRole={userRole} />
      </div>
    </div>
  )
}
