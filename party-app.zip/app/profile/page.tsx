"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { BottomNav } from "@/components/bottom-nav"
import { SidebarNav } from "@/components/sidebar-nav"
import { Settings, LogOut, Calendar, Users, Award } from "lucide-react"
import { mockUsers, mockEvents } from "@/lib/mock-data"

export default function ProfilePage() {
  const router = useRouter()
  const [userRole, setUserRole] = useState<"host" | "guest" | null>(null)
  const [userEmail, setUserEmail] = useState<string>("")

  useEffect(() => {
    const role = localStorage.getItem("userRole") as "host" | "guest" | null
    const email = localStorage.getItem("userEmail") || ""
    if (!role) {
      router.push("/")
      return
    }
    setUserRole(role)
    setUserEmail(email)
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("userRole")
    localStorage.removeItem("userEmail")
    router.push("/")
  }

  if (!userRole) {
    return null
  }

  const currentUser = mockUsers[0]
  const hostedEvents = mockEvents.filter((e) => e.hostId === currentUser.id)
  const attendedEvents = mockEvents.filter((e) => e.attendees.includes(currentUser.id))

  return (
    <div className="min-h-screen bg-secondary">
      <div className="hidden lg:block">
        <SidebarNav userRole={userRole} />
      </div>

      <div className="lg:ml-64 pb-20 lg:pb-8">
        <header className="bg-background border-b sticky top-0 z-10">
          <div className="max-w-2xl mx-auto px-4 py-4 flex items-center justify-between">
            <h1 className="text-xl font-bold">Mi Perfil</h1>
            <Button variant="ghost" size="icon">
              <Settings className="h-5 w-5" />
            </Button>
          </div>
        </header>

        <main className="max-w-2xl mx-auto px-4 py-6 space-y-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col items-center text-center space-y-4">
                <Avatar className="h-24 w-24">
                  <AvatarImage src={currentUser.avatar || "/placeholder.svg"} alt={currentUser.name} />
                  <AvatarFallback className="text-2xl">{currentUser.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <h2 className="text-2xl font-bold">{currentUser.name}</h2>
                  <p className="text-muted-foreground">{userEmail}</p>
                  <Badge className="mt-2" variant={userRole === "host" ? "default" : "secondary"}>
                    {userRole === "host" ? "Anfitrión" : "Invitado"}
                  </Badge>
                </div>
              </div>

              <Separator className="my-6" />

              <div className="grid grid-cols-3 gap-4 text-center">
                <div className="space-y-1">
                  <p className="text-2xl font-bold text-primary">{hostedEvents.length}</p>
                  <p className="text-xs text-muted-foreground">Eventos Creados</p>
                </div>
                <div className="space-y-1">
                  <p className="text-2xl font-bold text-primary">{attendedEvents.length}</p>
                  <p className="text-xs text-muted-foreground">Eventos Asistidos</p>
                </div>
                <div className="space-y-1">
                  <p className="text-2xl font-bold text-primary">12</p>
                  <p className="text-xs text-muted-foreground">Conexiones</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Logros</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                <div className="flex items-center gap-3 p-3 rounded-lg bg-secondary">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <Award className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-sm">Organizador Pro</p>
                    <p className="text-xs text-muted-foreground">5+ eventos</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-lg bg-secondary">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <Users className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-sm">Social</p>
                    <p className="text-xs text-muted-foreground">10+ asistencias</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Acciones Rápidas</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button
                variant="outline"
                className="w-full justify-start gap-3 bg-transparent"
                onClick={() => router.push("/history")}
              >
                <Calendar className="h-5 w-5" />
                Ver Historial de Eventos
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start gap-3 bg-transparent text-destructive hover:text-destructive"
                onClick={handleLogout}
              >
                <LogOut className="h-5 w-5" />
                Cerrar Sesión
              </Button>
            </CardContent>
          </Card>
        </main>
      </div>

      <div className="lg:hidden">
        <BottomNav userRole={userRole} />
      </div>
    </div>
  )
}
