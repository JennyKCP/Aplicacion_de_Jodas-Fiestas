"use client"

import { Home, Search, PlusCircle, Calendar, User } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

interface BottomNavProps {
  userRole: "host" | "guest"
}

export function BottomNav({ userRole }: BottomNavProps) {
  const pathname = usePathname()

  const navItems = [
    { href: "/feed", icon: Home, label: "Inicio" },
    { href: "/search", icon: Search, label: "Buscar" },
    ...(userRole === "host" ? [{ href: "/create-event", icon: PlusCircle, label: "Crear" }] : []),
    { href: "/my-events", icon: Calendar, label: "Eventos" },
    { href: "/profile", icon: User, label: "Perfil" },
  ]

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-card border-t border-border md:hidden">
      <div className="flex items-center justify-around h-16">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = pathname === item.href

          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex flex-col items-center justify-center gap-1 flex-1 h-full transition-colors",
                isActive ? "text-primary" : "text-muted-foreground hover:text-foreground",
              )}
            >
              <Icon className="h-5 w-5" />
              <span className="text-xs font-medium">{item.label}</span>
            </Link>
          )
        })}
      </div>
    </nav>
  )
}
