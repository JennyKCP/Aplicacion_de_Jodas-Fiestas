"use client"

import { useEffect, useState } from "react"
import { useRouter, useParams } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { BottomNav } from "@/components/bottom-nav"
import { SidebarNav } from "@/components/sidebar-nav"
import { ArrowLeft, MapPin, Navigation, Share2 } from "lucide-react"
import { mockEvents } from "@/lib/mock-data"
import type { Event } from "@/lib/types"

export default function EventMapPage() {
  const router = useRouter()
  const params = useParams()
  const [userRole, setUserRole] = useState<"host" | "guest" | null>(null)
  const [event, setEvent] = useState<Event | null>(null)

  useEffect(() => {
    const role = localStorage.getItem("userRole") as "host" | "guest" | null
    if (!role) {
      router.push("/")
      return
    }
    setUserRole(role)

    const foundEvent = mockEvents.find((e) => e.id === params.id)
    setEvent(foundEvent || null)
  }, [router, params.id])

  const handleGetDirections = () => {
    if (event) {
      const encodedLocation = encodeURIComponent(event.location)
      window.open(`https://www.google.com/maps/search/?api=1&query=${encodedLocation}`, "_blank")
    }
  }

  const handleShare = () => {
    if (event) {
      const shareText = `📍 Ubicación del evento: ${event.name}\n${event.location}`
      if (navigator.share) {
        navigator.share({
          title: event.name,
          text: shareText,
        })
      } else {
        navigator.clipboard.writeText(shareText)
        alert("Ubicación copiada al portapapeles")
      }
    }
  }

  if (!userRole || !event) {
    return null
  }

  return (
    <div className="min-h-screen bg-secondary">
      <div className="hidden lg:block">
        <SidebarNav userRole={userRole} />
      </div>

      <div className="lg:ml-64 pb-20 lg:pb-8">
        <header className="bg-background border-b sticky top-0 z-10">
          <div className="max-w-2xl mx-auto px-4 py-4 flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => router.back()}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-bold flex-1">Mapa del Evento</h1>
            <Button variant="ghost" size="icon" onClick={handleShare}>
              <Share2 className="h-5 w-5" />
            </Button>
          </div>
        </header>

        <main className="max-w-2xl mx-auto px-4 py-6 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5 text-primary" />
                Ubicación del Evento
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="font-semibold text-lg">{event.name}</p>
                <p className="text-muted-foreground mt-1">{event.location}</p>
              </div>

              <div className="relative w-full h-96 rounded-xl overflow-hidden border-2 border-border">
                <iframe
                  src={`https://www.google.com/maps/embed/v1/place?key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8&q=${encodeURIComponent(event.location)}`}
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Mapa del evento"
                />
              </div>

              <div className="grid grid-cols-1 gap-3">
                <Button onClick={handleGetDirections} className="gap-2" size="lg">
                  <Navigation className="h-4 w-4" />
                  Obtener Direcciones
                </Button>
              </div>

              <Card className="bg-muted/50">
                <CardContent className="pt-6">
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Información Adicional</p>
                    <p className="text-sm text-muted-foreground">
                      Fecha:{" "}
                      {new Date(event.date).toLocaleDateString("es-ES", {
                        weekday: "long",
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })}
                    </p>
                    <p className="text-sm text-muted-foreground">Hora: {event.time}</p>
                  </div>
                </CardContent>
              </Card>
            </CardContent>
          </Card>
        </main>
      </div>

      <div className="lg:hidden">
        <BottomNav userRole={userRole} />
      </div>
    </div>
  )
}
